# Sentiment-Analysis-of-IRCTC-App-Reviews

- Developed a sentiment analysis model to process IRCTC app user reviews and predict whether it is a positive or negetive review.

- Implemented various classical models for this classification and generated best predictions via LSTM model.


----


1. Sentiment_ Different Models: Here, I have implemented various classical models for sentiment classification. Both binary and multiclass classification have been implemented. However, binary classification worked best. (Binary Classification: if score<=2 : class=0 if score>2 : class=1)
2. Sentiment_LIVE: Live predictions via LSTM model.
